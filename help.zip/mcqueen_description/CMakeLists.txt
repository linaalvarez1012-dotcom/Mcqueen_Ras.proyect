cmake_minimum_required(VERSION 3.8)
project(mcqueen_description)

find_package(ament_cmake)

install(
    DIRECTORY config launch urdf rviz meshes 
    DESTINATION share/${PROJECT_NAME}/
)

ament_package()